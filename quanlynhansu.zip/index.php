<?php 

	// go to pages index
	header('Location: pages/index.php?p=index&a=statistic');

?>